document.addEventListener('DOMContentLoaded', () => {

  const scoreDisplay = document.getElementById('score')
  const highScoreDisplay = document.getElementById('highScores')
  const width = 28
  let highScore = []
  let score = 0
  let counter = 0
  let gameOver = false
  const grid = document.querySelector('.grid')
  const layout = [
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,3,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,3,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,4,4,4,4,4,4,4,4,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,1,1,2,2,1,1,1,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,2,2,2,2,2,2,1,4,1,1,0,1,1,1,1,1,1,
    4,4,4,4,4,4,0,0,0,4,1,2,2,2,2,2,2,1,4,0,0,0,4,4,4,4,4,4,
    1,1,1,1,1,1,0,1,1,4,1,2,2,2,2,2,2,1,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,1,1,1,1,1,1,1,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,1,1,1,1,1,1,1,4,1,1,0,1,1,1,1,1,1,
    1,0,0,0,0,0,0,0,0,4,4,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,3,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,3,1,
    1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,
    1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,
    1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1,
    1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,
    1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
  ]
  // 0 - pac-dots
  // 1 - wall
  // 2 - ghost-lair
  // 3 - power-pellet
  // 4 - empty

  let squares = []

  //create your board
  function createBoard() {
    for (let i = 0; i < layout.length; i++) {
      const square = document.createElement('div')
      grid.appendChild(square)
      squares.push(square)

      //add layout to the board
      if(layout[i] === 0) {
        squares[i].classList.add('pac-dot')
      } else if (layout[i] === 1) {
        squares[i].classList.add('wall')
      } else if (layout[i] === 2) {
        squares[i].classList.add('ghost-lair')
      } else if (layout[i] === 3) {
        squares[i].classList.add('power-pellet')
      }
    }
  }

  createBoard()

  //pacman starting position
  let pacmanCurrentIndex = 490

  squares[pacmanCurrentIndex].classList.add('pacman')

  //move pacman
  function movePacman(e) {
    squares[pacmanCurrentIndex].classList.remove('pacman')

    switch(e.key) {
      case 'ArrowLeft':
        if(pacmanCurrentIndex % width !==0 && !squares[pacmanCurrentIndex -1].classList.contains('wall') && !squares[pacmanCurrentIndex -1].classList.contains('ghost-lair')) pacmanCurrentIndex -=1
        // check if pacman is in the left exit
        if(pacmanCurrentIndex -1 === 363) {
          pacmanCurrentIndex = 391
        }
        break
      case 'ArrowUp':
        if(pacmanCurrentIndex - width >=0 && !squares[pacmanCurrentIndex -width].classList.contains('wall') && !squares[pacmanCurrentIndex -width].classList.contains('ghost-lair')) pacmanCurrentIndex -=width
        break
      case 'ArrowRight':
        if(pacmanCurrentIndex % width < width -1 && !squares[pacmanCurrentIndex +1].classList.contains('wall') && !squares[pacmanCurrentIndex +1].classList.contains('ghost-lair')) pacmanCurrentIndex +=1
        // check if pacman is in the right exit
        if(pacmanCurrentIndex +1 === 392) {
          pacmanCurrentIndex = 364
        }
        break
      case 'ArrowDown':
        if(pacmanCurrentIndex + width < width * width && !squares[pacmanCurrentIndex +width].classList.contains('wall') && !squares[pacmanCurrentIndex +width].classList.contains('ghost-lair')) pacmanCurrentIndex +=width
        break
    }
    squares[pacmanCurrentIndex].classList.add('pacman')

    pacDotEaten()
    powerPelletEaten()
    checkGameOver()
    checkForWin()

  }

  document.addEventListener('keyup', movePacman)

  //what happens when pacman eats a pac-dot
  function pacDotEaten() {
    if (squares[pacmanCurrentIndex].classList.contains('pac-dot')){
    score++
    scoreDisplay.innerHTML = score
    squares[pacmanCurrentIndex].classList.remove('pac-dot')
    }
  }

  //what happens when pacman eats a power-pellet
  function powerPelletEaten() {
    if (squares[pacmanCurrentIndex].classList.contains('power-pellet')){
    score +=10
    ghosts.forEach(ghost => ghost.isScared = true)
    setTimeout(unScaredGhosts, 10000)
    scoreDisplay.innerHTML = score
    squares[pacmanCurrentIndex].classList.remove('power-pellet')
    }
  }

  function unScaredGhosts() {
    ghosts.forEach(ghost => ghost.isScared = false)
  }

  function checkForWin() {
    console.log('You Win!')
  }

  //create ghost template
  class Ghost {
    constructor(className, startIndex, speed) {
      this.className = className
      this.startIndex = startIndex
      this.speed = speed
      this.currentIndex = startIndex
      this.timerId = NaN
      this.isScared = false
    }
  }

  ghosts = [
    new Ghost('blinky', 348, 250),
    new Ghost('pinky', 376, 400),
    new Ghost('inky', 351, 300),
    new Ghost('clyde', 379, 500)
  ]

  //add ghosts to grid

  ghosts.forEach(ghost => {
    squares[ghost.currentIndex].classList.add(ghost.className)
    squares[ghost.currentIndex].classList.add('ghost')
  })

  //move all ghosts randomly
  ghosts.forEach(ghost => moveGhost(ghost))

  //move ghosts function
  function moveGhost(ghost){
    const directions = [-1,+1,width,-width]
    let direction = directions[Math.floor(Math.random()*directions.length)]
    ghost.timerId = setInterval(function (){
      //if the square being moved into does not contain a wall, ghost, etc.
      if(!squares[ghost.currentIndex + direction].classList.contains('wall') && !squares[ghost.currentIndex + direction].classList.contains('ghost')) {
        //go there
        //remove all ghost classes
        squares[ghost.currentIndex].classList.remove(ghost.className, 'ghost', 'scared-ghost')
        //change currentIndex to new safe square
        ghost.currentIndex +=direction
        //redraw ghost in new safe square
        squares[ghost.currentIndex].classList.add(ghost.className, 'ghost')

      //else find new direction to move
      } else direction = directions[Math.floor(Math.random()*directions.length)]

      //if ghost is scared
      if (ghost.isScared) {
        squares[ghost.currentIndex].classList.add('scared-ghost')
      }

      //if pacman eats ghost
      if(ghost.isScared && squares[ghost.currentIndex].classList.contains('pacman')) {
        squares[ghost.currentIndex].classList.remove(ghost.className, 'ghost', 'scared-ghost')
        ghost.currentIndex = ghost.startIndex
        score += 100
        squares[ghost.currentIndex].classList.add(ghost.className, 'ghost')
      }
      checkGameOver()
    }, ghost.speed)
  }

  //check for game over
  function checkGameOver() {
    if (squares[pacmanCurrentIndex].classList.contains('ghost') && !squares[pacmanCurrentIndex].classList.contains('scared-ghost')) {
      ghosts.forEach(ghost => clearInterval(ghost.timerId))
      document.removeEventListener('keyup', movePacman)
      // setTimeout(function(){alert('Game Over! Your score is: ' + score)},500)
      scoreDisplay.innerHTML = ' Game Over! Your score is: ' + score
      console.log(counter)
      playAgain()
    }
  }

  function checkForWin() {
    counter = 0
    squares.forEach(square => {
      if (square.classList.contains('pac-dot') || square.classList.contains('power-pellet')) {
        counter++
      }
    })
    if (counter === 0) {
      ghosts.forEach(ghost => clearInterval(ghost.timerId))
      document.removeEventListener('keyup', movePacman)
      scoreDisplay.innerHTML = ' You Win! Your score is: ' + score
      console.log(counter)
      playAgain()
    }
  }

  function manageScores() {
    highScore.unshift(score)
    highScoreDisplay.innerHTML = 'High Scores: <BR/>' + highScore.sort(function(a, b){return b-a}).join('<BR/>')
  }

  function resetBoard() {
    if (squares.length > 0) {
      manageScores()
      score = 0
      scoreDisplay.innerHTML = score
      gameOver = false
      squares = []
      while (grid.lastElementChild) {
        grid.removeChild(grid.lastElementChild)
      }
    }
  }

  function playAgain() {
    let isConfirmed = confirm('Would you like to play again?')
    if (isConfirmed === true) {

      resetBoard()
      createBoard()

      document.addEventListener('keyup', movePacman)

      pacmanCurrentIndex = 490
      squares[pacmanCurrentIndex].classList.add('pacman')

      ghosts = [
        new Ghost('blinky', 348, 250),
        new Ghost('pinky', 376, 400),
        new Ghost('inky', 351, 300),
        new Ghost('clyde', 379, 500)
      ]

      ghosts.forEach(ghost => {
        squares[ghost.currentIndex].classList.add(ghost.className)
        squares[ghost.currentIndex].classList.add('ghost')
      })

      //move all ghosts randomly
      ghosts.forEach(ghost => moveGhost(ghost))

    } else {
      scoreDisplay.innerHTML = 'Game Over! Your score is: ' + score
      manageScores()
    }
  }







})
